// Año dinámico en el pie de página
document.getElementById("year").textContent = new Date().getFullYear();

// Botón para copiar usuario de Instagram
document.getElementById("copyInsta").addEventListener("click", async () => {
  const user = "@la_delicia_de_brownies";
  try {
    await navigator.clipboard.writeText(user);
    alert("Usuario copiado: " + user);
  } catch (err) {
    prompt("Copia el usuario:", user);
  }
});
